import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

export function ControlPanel() {
  const [selectedLocation, setSelectedLocation] = useState("");
  const [, setLocation] = useLocation();

  const handleSubmit = () => {
    if (selectedLocation) {
      setLocation(`/proxy-session?location=${selectedLocation}`);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Select Proxy Location</CardTitle>
          <p className="text-gray-600">Choose a proxy location to get started</p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Location Selection */}
          <div className="max-w-md mx-auto">
            <Label htmlFor="location" className="flex items-center justify-center text-sm font-medium text-gray-700 mb-3">
              <MapPin className="w-4 h-4 text-gray-400 mr-2" />
              Select Proxy Location
            </Label>
            <Select 
              value={selectedLocation} 
              onValueChange={setSelectedLocation}
            >
              <SelectTrigger data-testid="select-location" className="text-lg h-12">
                <SelectValue placeholder="Choose Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="usa">🇺🇸 United States</SelectItem>
                <SelectItem value="canada">🇨🇦 Canada</SelectItem>
                <SelectItem value="australia">🇦🇺 Australia</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Submit Button */}
          <div className="text-center pt-4">
            <Button
              onClick={handleSubmit}
              disabled={!selectedLocation}
              className="bg-primary hover:bg-primary/90 px-8 py-3 text-lg"
              data-testid="button-submit-location"
            >
              Continue with {selectedLocation === "usa" ? "🇺🇸 United States" : 
                           selectedLocation === "canada" ? "🇨🇦 Canada" : 
                           selectedLocation === "australia" ? "🇦🇺 Australia" : "Selected Location"}
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
