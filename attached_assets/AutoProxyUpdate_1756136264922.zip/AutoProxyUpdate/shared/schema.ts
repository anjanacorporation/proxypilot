import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const proxyServers = pgTable("proxy_servers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  host: text("host").notNull(),
  port: integer("port").notNull(),
  country: text("country").notNull(),
  city: text("city"),
  isActive: boolean("is_active").default(true),
  responseTime: integer("response_time"),
  lastChecked: timestamp("last_checked"),
});

export const proxySessions = pgTable("proxy_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetUrl: text("target_url").notNull(),
  location: text("location").notNull(),
  refreshInterval: integer("refresh_interval").notNull(),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`),
});

export const screenInstances = pgTable("screen_instances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => proxySessions.id),
  screenNumber: integer("screen_number").notNull(),
  proxyId: varchar("proxy_id").references(() => proxyServers.id),
  status: text("status").default("inactive"), // inactive, loading, active, error
  lastRefresh: timestamp("last_refresh"),
});

export const systemLogs = pgTable("system_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  level: text("level").notNull(), // info, warning, error, success
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").default(sql`now()`),
});

export const insertProxyServerSchema = createInsertSchema(proxyServers).omit({
  id: true,
  lastChecked: true,
});

export const insertProxySessionSchema = createInsertSchema(proxySessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertScreenInstanceSchema = createInsertSchema(screenInstances).omit({
  id: true,
  lastRefresh: true,
});

export const insertSystemLogSchema = createInsertSchema(systemLogs).omit({
  id: true,
  timestamp: true,
});

export type ProxyServer = typeof proxyServers.$inferSelect;
export type InsertProxyServer = z.infer<typeof insertProxyServerSchema>;

export type ProxySession = typeof proxySessions.$inferSelect;
export type InsertProxySession = z.infer<typeof insertProxySessionSchema>;

export type ScreenInstance = typeof screenInstances.$inferSelect;
export type InsertScreenInstance = z.infer<typeof insertScreenInstanceSchema>;

export type SystemLog = typeof systemLogs.$inferSelect;
export type InsertSystemLog = z.infer<typeof insertSystemLogSchema>;
