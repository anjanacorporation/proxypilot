import { Header } from "@/components/Header";
import { DownloadSection } from "@/components/DownloadSection";

export default function Downloads() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Application Downloads</h1>
          <p className="text-gray-600 max-w-2xl">
            Download the Multi-Proxy Screen Manager for your platform. Our desktop applications provide 
            the same powerful proxy management features with a native interface optimized for your operating system.
          </p>
        </div>
        
        <DownloadSection />
        
        {/* Installation Instructions */}
        <div className="mt-12 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Installation Instructions</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-3">🖥️ Windows</h3>
              <ol className="text-sm text-gray-600 space-y-1">
                <li>1. Download the .exe file</li>
                <li>2. Run the installer as administrator</li>
                <li>3. Follow the setup wizard</li>
                <li>4. Launch from Start Menu</li>
              </ol>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">🍎 macOS</h3>
              <ol className="text-sm text-gray-600 space-y-1">
                <li>1. Download the .dmg file</li>
                <li>2. Open the disk image</li>
                <li>3. Drag app to Applications folder</li>
                <li>4. Launch from Applications</li>
              </ol>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">🐧 Linux</h3>
              <ol className="text-sm text-gray-600 space-y-1">
                <li>1. Download the .AppImage file</li>
                <li>2. Make it executable: chmod +x</li>
                <li>3. Run the AppImage file</li>
                <li>4. Optionally integrate with system</li>
              </ol>
            </div>
          </div>
        </div>
        
        {/* System Requirements */}
        <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">System Requirements</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Minimum Requirements</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 4 GB RAM</li>
                <li>• 2 GB Storage</li>
                <li>• Internet Connection</li>
                <li>• Modern Browser Engine</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Recommended</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 8 GB RAM</li>
                <li>• 4 GB Storage</li>
                <li>• High-speed Internet</li>
                <li>• Dedicated Graphics</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-3">Supported OS</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Windows 10/11</li>
                <li>• macOS 10.15+</li>
                <li>• Ubuntu 18.04+</li>
                <li>• Other modern distributions</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
