# Multi-Proxy Screen Manager

A full-stack application for managing multiple proxy screens with automatic proxy rotation, real-time monitoring, and cross-platform desktop/mobile applications.

## 🚀 Features

- **10-Screen Grid Layout**: View websites through 10 different proxy screens simultaneously
- **Location Selection**: Choose from USA, Canada, and Australia proxy servers
- **Automatic Proxy Rotation**: Background service updates proxy servers every 5 minutes
- **Real-time Monitoring**: Live status updates and system logs
- **Auto Refresh**: Configurable refresh intervals (15s, 30s, 60s)
- **Cross-platform Desktop Apps**: Electron-based apps for Windows, macOS, and Linux
- **Mobile WebView Apps**: React Native apps for Android and iOS
- **Modern UI**: Responsive design with Tailwind CSS and Shadcn/ui components

## 📋 System Requirements

### Minimum Requirements
- 4 GB RAM
- 2 GB Storage
- Internet Connection
- Modern Browser Engine

### Recommended
- 8 GB RAM
- 4 GB Storage
- High-speed Internet
- Dedicated Graphics

## 🛠️ Installation & Setup

### 1. Web Application (Default)

The web application is already set up and running. Simply access the dashboard to:

1. Select a proxy location (USA, Canada, Australia)
2. Enter a target URL (e.g., https://google.com)
3. Choose refresh interval (15s, 30s, 60s)
4. Click "Start Sessions" to launch 10 proxy screens

### 2. Desktop Applications

Build desktop applications for Windows, macOS, and Linux:

```bash
# Build desktop apps
node scripts/build-desktop.js

# Or build for specific platform
cd electron
npm install
npm run build-win    # Windows .exe
npm run build-mac    # macOS .dmg
npm run build-linux  # Linux .AppImage
```

Built files will be available in the `downloads/` directory.

### 3. Mobile Applications

Set up mobile apps using React Native and Expo:

```bash
# Setup mobile app environment
node scripts/build-mobile.js

# Follow the setup instructions:
cd mobile-app
./setup.sh

# Login to Expo and configure builds
eas login
eas build:configure

# Build for Android
eas build --platform android

# Build for iOS (requires Apple Developer account)
eas build --platform ios
```

## 🏗️ Project Structure

```
project/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── pages/         # Application pages
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # API client and utilities
├── server/                # Express.js backend
│   ├── routes.ts          # API routes
│   ├── storage.ts         # Data storage layer
│   ├── proxyUpdater.ts    # Auto proxy scraper
│   └── index.ts           # Server entry point
├── shared/                # Shared TypeScript schemas
├── electron/              # Desktop app wrapper
├── mobile-app/            # React Native mobile app
├── scripts/               # Build scripts
└── downloads/             # Built application files
```

## 🔧 Configuration

### Proxy Settings

The application comes pre-configured with working proxy servers for:
- **USA**: 4 proxy servers
- **Canada**: 3 proxy servers  
- **Australia**: 3 proxy servers

### Auto Proxy Updates

The background service automatically:
- Updates proxy lists every 5 minutes
- Tests proxy health and response times
- Adds new working proxies to the system
- Logs all activity in system logs

### Session Management

- **Start Session**: Creates 10 screen instances with rotating proxy assignments
- **Stop Session**: Terminates all active screens and clears session data
- **Refresh All**: Manually refreshes all active screens
- **Auto Refresh**: Automatically refreshes based on configured interval

## 📱 Platform Support

### Desktop Applications
- **Windows**: Compatible with Windows 10 and 11 (.exe installer)
- **macOS**: Compatible with macOS 10.15+ (.dmg installer)
- **Linux**: AppImage format for all distributions

### Mobile Applications
- **Android**: WebView wrapper for mobile access (.apk)
- **iOS**: WebView wrapper for iPhone/iPad (via App Store)

## 🔍 Monitoring & Logging

### System Logs
- Real-time log display with color-coded severity levels
- Success, Info, Warning, and Error messages
- Timestamps for all log entries
- Clear logs functionality

### Proxy Status Monitor
- Live proxy count by country
- Average response times
- Active/inactive proxy ratios
- Auto-update status indicators

## 🚦 API Endpoints

### Session Management
- `GET /api/session` - Get active session
- `POST /api/session/start` - Start new proxy session
- `POST /api/session/stop` - Stop active session
- `POST /api/session/refresh` - Refresh all screens

### Proxy Management
- `GET /api/proxies` - Get all proxy servers
- `GET /api/proxies/:country` - Get proxies by country
- `GET /api/proxy/:screenId?url=<url>` - Proxy content through screen

### System Operations
- `GET /api/logs` - Get system logs
- `DELETE /api/logs` - Clear system logs
- `GET /api/downloads/:platform` - Download desktop apps

## 🔒 Security Features

- **CORS Protection**: Proper cross-origin request handling
- **Input Validation**: Zod schema validation for all API inputs
- **Proxy Sandboxing**: Isolated iframe environments for proxy content
- **Session Management**: Secure session state management
- **Error Handling**: Comprehensive error logging and user feedback

## 🎨 UI Components

Built with modern, accessible components:
- **Control Panel**: Location selection, URL input, refresh intervals
- **Screen Grid**: 2×5 grid layout for 10 proxy screens
- **Proxy Status**: Live monitoring of proxy servers by country
- **System Logs**: Real-time log viewer with filtering
- **Download Section**: Desktop and mobile app downloads

## 📊 Performance Optimization

- **Lazy Loading**: Components load on demand
- **Caching**: TanStack Query for intelligent data caching
- **Auto Refresh**: Efficient polling for real-time updates
- **Proxy Health Checks**: Background monitoring of proxy availability
- **Error Recovery**: Automatic retry mechanisms for failed requests

## 🔄 Development Workflow

### Local Development
1. Start the development server: The application is already running
2. Access the dashboard at the current URL
3. Use the browser developer tools for debugging
4. Hot module replacement is enabled for instant updates

### Building for Production
1. Build web application: `npm run build`
2. Build desktop apps: `node scripts/build-desktop.js`
3. Build mobile apps: `node scripts/build-mobile.js`

## 📝 Troubleshooting

### Common Issues

**Proxy Screens Not Loading**
- Check if the target URL is accessible
- Verify proxy servers are active in Proxy Status section
- Try refreshing the session or restarting

**Desktop App Build Fails**
- Ensure all dependencies are installed: `cd electron && npm install`
- Check system requirements for Electron builds
- Verify platform-specific build tools are available

**Mobile App Setup Issues**
- Install Expo CLI globally: `npm install -g @expo/eas-cli`
- Create Expo account at https://expo.dev
- Follow mobile app setup instructions in the build script

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

## 📞 Support

For technical support or feature requests:
- Check system logs for error details
- Review proxy status for connectivity issues
- Contact development team for additional assistance

---

**Built with**: React, TypeScript, Express.js, Electron, React Native, Tailwind CSS, Shadcn/ui