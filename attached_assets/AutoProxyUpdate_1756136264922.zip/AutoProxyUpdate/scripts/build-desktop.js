#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Building Multi-Proxy Screen Manager Desktop Apps...\n');

// Check if electron directory exists
if (!fs.existsSync('electron')) {
  console.error('❌ Electron directory not found!');
  process.exit(1);
}

// Function to run command and handle errors
function runCommand(command, description) {
  console.log(`📦 ${description}...`);
  try {
    execSync(command, { stdio: 'inherit', cwd: process.cwd() });
    console.log(`✅ ${description} completed!\n`);
  } catch (error) {
    console.error(`❌ ${description} failed:`, error.message);
    process.exit(1);
  }
}

// Build steps
try {
  // Build the web application first
  console.log('🏗️  Building web application...');
  runCommand('npm run build', 'Web application build');

  // Install electron dependencies
  console.log('📥 Installing Electron dependencies...');
  process.chdir('electron');
  runCommand('npm install', 'Electron dependencies installation');

  // Build for all platforms
  console.log('🔨 Building desktop applications...');
  
  const buildCommands = [
    { cmd: 'npm run build-win', desc: 'Windows (.exe) build', platform: 'win32' },
    { cmd: 'npm run build-mac', desc: 'macOS (.dmg) build', platform: 'darwin' },
    { cmd: 'npm run build-linux', desc: 'Linux (.AppImage) build', platform: 'linux' }
  ];

  for (const { cmd, desc, platform } of buildCommands) {
    if (process.platform === platform || process.argv.includes('--all')) {
      runCommand(cmd, desc);
    } else {
      console.log(`⏭️  Skipping ${desc} (not on ${platform})`);
    }
  }

  // Create downloads directory and move built files
  const downloadsDir = path.join('..', 'downloads');
  if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
  }

  // Copy built files to downloads directory
  const distDir = path.join('dist');
  if (fs.existsSync(distDir)) {
    const files = fs.readdirSync(distDir);
    files.forEach(file => {
      const srcPath = path.join(distDir, file);
      const destPath = path.join(downloadsDir, file);
      
      if (fs.statSync(srcPath).isFile()) {
        fs.copyFileSync(srcPath, destPath);
        console.log(`📁 Copied ${file} to downloads/`);
      }
    });
  }

  console.log('\n🎉 Desktop application build completed!');
  console.log('📂 Built files are available in the downloads/ directory');
  console.log('\n📋 Available builds:');
  console.log('   • Windows: ProxyManager-1.0.0.exe');
  console.log('   • macOS: ProxyManager-1.0.0.dmg');
  console.log('   • Linux: ProxyManager-1.0.0.AppImage');

} catch (error) {
  console.error('❌ Build process failed:', error.message);
  process.exit(1);
}