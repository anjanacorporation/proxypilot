import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Globe } from "lucide-react";
import { useProxySession } from "@/hooks/useProxySession";

interface ScreenItemProps {
  screenNumber: number;
  status: string;
  targetUrl?: string;
}

function ScreenItem({ screenNumber, status, targetUrl }: ScreenItemProps) {
  const isActive = status === "active";
  const proxyUrl = targetUrl ? `/api/proxy/${screenNumber}?url=${encodeURIComponent(targetUrl)}` : null;

  return (
    <div className="relative bg-gray-100 rounded-lg border border-gray-200 overflow-hidden aspect-video">
      <div className="absolute top-2 left-2 z-10">
        <div className="flex items-center space-x-2">
          <span className="bg-gray-800 text-white text-xs px-2 py-1 rounded">
            Screen {screenNumber}
          </span>
          <div className="flex items-center bg-gray-800 text-white text-xs px-2 py-1 rounded">
            <div className={`w-2 h-2 rounded-full mr-1 ${
              isActive ? "bg-green-400 animate-pulse" : "bg-gray-400"
            }`} />
            <span>{isActive ? "Active" : "Inactive"}</span>
          </div>
        </div>
      </div>
      
      {!isActive || !proxyUrl ? (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-gray-500">
            <Globe className="w-8 h-8 mb-2 text-gray-400 mx-auto" />
            <p className="text-sm">Waiting for URL...</p>
          </div>
        </div>
      ) : (
        <iframe
          src={proxyUrl}
          className="w-full h-full"
          title={`Screen ${screenNumber}`}
          sandbox="allow-same-origin allow-scripts allow-forms"
          data-testid={`iframe-screen-${screenNumber}`}
        />
      )}
    </div>
  );
}

export function ScreenGrid() {
  const { sessionData } = useProxySession();
  
  const lastUpdated = sessionData?.session?.updatedAt 
    ? new Date(sessionData.session.updatedAt).toLocaleTimeString()
    : "--:--";

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Proxy Screens</CardTitle>
          <div className="text-sm text-gray-500">
            Grid Layout: 2×5 | Last Updated: <span data-testid="last-updated">{lastUpdated}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {Array.from({ length: 10 }, (_, i) => {
            const screenNumber = i + 1;
            const screenInstance = sessionData?.screens?.find(s => s.screenNumber === screenNumber);
            
            return (
              <ScreenItem
                key={screenNumber}
                screenNumber={screenNumber}
                status={screenInstance?.status || "inactive"}
                targetUrl={sessionData?.session?.targetUrl}
              />
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
