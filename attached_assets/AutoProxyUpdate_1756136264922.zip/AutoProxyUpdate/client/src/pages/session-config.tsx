import { useState } from "react";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link2, Clock, Play, Square, RefreshCw, ArrowLeft } from "lucide-react";
import { useProxySession } from "@/hooks/useProxySession";
import { Link } from "wouter";

export default function SessionConfig() {
  const [targetUrl, setTargetUrl] = useState("");
  const [refreshInterval, setRefreshInterval] = useState("30");
  const [selectedLocation, setSelectedLocation] = useState("");
  
  const {
    sessionData,
    isSessionActive,
    startSession,
    stopSession,
    refreshAllScreens,
    isStarting,
    isStopping,
    isRefreshing,
  } = useProxySession();

  const handleStart = () => {
    if (!selectedLocation || !targetUrl) {
      return;
    }
    
    startSession({
      targetUrl,
      location: selectedLocation,
      refreshInterval: parseInt(refreshInterval),
    });
  };

  const activeScreensCount = sessionData?.screens?.filter(screen => screen.status === "active").length || 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Session Configuration</h1>
          <p className="text-gray-600">Configure your proxy session settings and manage active sessions.</p>
        </div>

        <div className="space-y-8">
          {/* Proxy Location Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Proxy Location</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-w-md">
                <Label htmlFor="location" className="text-sm font-medium text-gray-700 mb-2 block">
                  Select Proxy Location
                </Label>
                <Select 
                  value={selectedLocation} 
                  onValueChange={setSelectedLocation}
                  disabled={isSessionActive}
                >
                  <SelectTrigger data-testid="select-location">
                    <SelectValue placeholder="Choose Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="usa">🇺🇸 United States</SelectItem>
                    <SelectItem value="canada">🇨🇦 Canada</SelectItem>
                    <SelectItem value="australia">🇦🇺 Australia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Target URL Configuration */}
          <Card>
            <CardHeader>
              <CardTitle>Target URL</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-w-2xl">
                <Label htmlFor="target-url" className="flex items-center text-sm font-medium text-gray-700 mb-2">
                  <Link2 className="w-4 h-4 text-gray-400 mr-2" />
                  Website URL
                </Label>
                <Input
                  id="target-url"
                  type="url"
                  placeholder="https://example.com"
                  value={targetUrl}
                  onChange={(e) => setTargetUrl(e.target.value)}
                  disabled={isSessionActive}
                  data-testid="input-target-url"
                  className="text-lg"
                />
                <p className="text-sm text-gray-500 mt-2">
                  Enter the website URL you want to view through proxy screens
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Refresh Interval Configuration */}
          <Card>
            <CardHeader>
              <CardTitle>Auto Refresh Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-w-md">
                <Label htmlFor="refresh-interval" className="flex items-center text-sm font-medium text-gray-700 mb-2">
                  <Clock className="w-4 h-4 text-gray-400 mr-2" />
                  Refresh Interval
                </Label>
                <Select 
                  value={refreshInterval} 
                  onValueChange={setRefreshInterval}
                  disabled={isSessionActive}
                >
                  <SelectTrigger data-testid="select-refresh-interval">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 seconds</SelectItem>
                    <SelectItem value="30">30 seconds</SelectItem>
                    <SelectItem value="60">60 seconds</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-gray-500 mt-2">
                  How often should all screens automatically refresh
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Session Control */}
          <Card>
            <CardHeader>
              <CardTitle>Session Control</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex space-x-4">
                  <Button
                    onClick={handleStart}
                    disabled={isSessionActive || isStarting || !selectedLocation || !targetUrl}
                    className="bg-primary hover:bg-primary/90"
                    data-testid="button-start-session"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {isStarting ? "Starting..." : "Start Proxy Session"}
                  </Button>
                  
                  <Button
                    onClick={() => stopSession()}
                    disabled={!isSessionActive || isStopping}
                    variant="destructive"
                    data-testid="button-stop-session"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    {isStopping ? "Stopping..." : "Stop Session"}
                  </Button>
                  
                  <Button
                    onClick={() => refreshAllScreens()}
                    disabled={!isSessionActive || isRefreshing}
                    variant="secondary"
                    data-testid="button-refresh-all"
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
                    {isRefreshing ? "Refreshing..." : "Refresh All"}
                  </Button>
                </div>

                <div className="flex items-center space-x-6">
                  <div className="flex items-center">
                    <div className={`w-3 h-3 rounded-full mr-2 ${
                      isSessionActive ? "bg-green-400 animate-pulse" : "bg-gray-400"
                    }`} />
                    <span className="text-sm text-gray-600" data-testid="status-text">
                      {isSessionActive ? "Session Active" : "Session Inactive"}
                    </span>
                  </div>
                  <div className="text-sm text-gray-500">
                    Active Screens: <span className="font-medium" data-testid="active-proxies-count">
                      {activeScreensCount}/10
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Session Info */}
          {sessionData?.session && (
            <Card>
              <CardHeader>
                <CardTitle>Current Session Info</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-700">Target URL:</span>
                    <p className="text-gray-600 break-all">{sessionData.session.targetUrl}</p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Location:</span>
                    <p className="text-gray-600 capitalize">{sessionData.session.location}</p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Refresh Interval:</span>
                    <p className="text-gray-600">{sessionData.session.refreshInterval} seconds</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}