import { 
  type ProxyServer, 
  type InsertProxyServer,
  type ProxySession,
  type InsertProxySession,
  type ScreenInstance,
  type InsertScreenInstance,
  type SystemLog,
  type InsertSystemLog
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Proxy Servers
  getProxyServers(): Promise<ProxyServer[]>;
  getProxyServersByCountry(country: string): Promise<ProxyServer[]>;
  createProxyServer(server: InsertProxyServer): Promise<ProxyServer>;
  updateProxyServer(id: string, updates: Partial<ProxyServer>): Promise<ProxyServer | undefined>;
  
  // Proxy Sessions
  getActiveSession(): Promise<ProxySession | undefined>;
  createProxySession(session: InsertProxySession): Promise<ProxySession>;
  updateProxySession(id: string, updates: Partial<ProxySession>): Promise<ProxySession | undefined>;
  deleteProxySession(id: string): Promise<boolean>;
  
  // Screen Instances
  getScreenInstancesBySession(sessionId: string): Promise<ScreenInstance[]>;
  createScreenInstance(instance: InsertScreenInstance): Promise<ScreenInstance>;
  updateScreenInstance(id: string, updates: Partial<ScreenInstance>): Promise<ScreenInstance | undefined>;
  deleteScreenInstancesBySession(sessionId: string): Promise<boolean>;
  
  // System Logs
  getSystemLogs(limit?: number): Promise<SystemLog[]>;
  createSystemLog(log: InsertSystemLog): Promise<SystemLog>;
  clearSystemLogs(): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private proxyServers: Map<string, ProxyServer>;
  private proxySessions: Map<string, ProxySession>;
  private screenInstances: Map<string, ScreenInstance>;
  private systemLogs: Map<string, SystemLog>;

  constructor() {
    this.proxyServers = new Map();
    this.proxySessions = new Map();
    this.screenInstances = new Map();
    this.systemLogs = new Map();
    
    // Initialize with some mock proxy servers
    this.initializeMockProxies();
  }

  private initializeMockProxies() {
    const mockProxies = [
      { host: "208.67.222.222", port: 53, country: "usa", city: "San Francisco", isActive: true, responseTime: 65 },
      { host: "8.8.8.8", port: 53, country: "usa", city: "Mountain View", isActive: true, responseTime: 45 },
      { host: "1.1.1.1", port: 53, country: "usa", city: "San Francisco", isActive: true, responseTime: 55 },
      { host: "208.67.220.220", port: 53, country: "usa", city: "San Jose", isActive: true, responseTime: 72 },
      { host: "149.112.112.112", port: 53, country: "canada", city: "Toronto", isActive: true, responseTime: 89 },
      { host: "9.9.9.9", port: 53, country: "canada", city: "Vancouver", isActive: true, responseTime: 67 },
      { host: "149.112.112.10", port: 53, country: "canada", city: "Montreal", isActive: true, responseTime: 95 },
      { host: "1.0.0.1", port: 53, country: "australia", city: "Sydney", isActive: true, responseTime: 178 },
      { host: "185.228.168.9", port: 53, country: "australia", city: "Melbourne", isActive: true, responseTime: 156 },
      { host: "185.228.169.9", port: 53, country: "australia", city: "Perth", isActive: true, responseTime: 203 },
    ];

    mockProxies.forEach(proxy => {
      const id = randomUUID();
      this.proxyServers.set(id, {
        id,
        ...proxy,
        lastChecked: new Date(),
      });
    });
  }

  async getProxyServers(): Promise<ProxyServer[]> {
    return Array.from(this.proxyServers.values());
  }

  async getProxyServersByCountry(country: string): Promise<ProxyServer[]> {
    return Array.from(this.proxyServers.values()).filter(
      server => server.country === country && server.isActive
    );
  }

  async createProxyServer(insertServer: InsertProxyServer): Promise<ProxyServer> {
    const id = randomUUID();
    const server: ProxyServer = {
      id,
      ...insertServer,
      isActive: insertServer.isActive ?? true,
      responseTime: insertServer.responseTime ?? null,
      lastChecked: new Date(),
    };
    this.proxyServers.set(id, server);
    return server;
  }

  async updateProxyServer(id: string, updates: Partial<ProxyServer>): Promise<ProxyServer | undefined> {
    const server = this.proxyServers.get(id);
    if (!server) return undefined;
    
    const updatedServer = { ...server, ...updates };
    this.proxyServers.set(id, updatedServer);
    return updatedServer;
  }

  async getActiveSession(): Promise<ProxySession | undefined> {
    return Array.from(this.proxySessions.values()).find(session => session.isActive);
  }

  async createProxySession(insertSession: InsertProxySession): Promise<ProxySession> {
    const id = randomUUID();
    const session: ProxySession = {
      id,
      ...insertSession,
      isActive: insertSession.isActive ?? false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.proxySessions.set(id, session);
    return session;
  }

  async updateProxySession(id: string, updates: Partial<ProxySession>): Promise<ProxySession | undefined> {
    const session = this.proxySessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates, updatedAt: new Date() };
    this.proxySessions.set(id, updatedSession);
    return updatedSession;
  }

  async deleteProxySession(id: string): Promise<boolean> {
    return this.proxySessions.delete(id);
  }

  async getScreenInstancesBySession(sessionId: string): Promise<ScreenInstance[]> {
    return Array.from(this.screenInstances.values()).filter(
      instance => instance.sessionId === sessionId
    );
  }

  async createScreenInstance(insertInstance: InsertScreenInstance): Promise<ScreenInstance> {
    const id = randomUUID();
    const instance: ScreenInstance = {
      id,
      ...insertInstance,
      sessionId: insertInstance.sessionId ?? null,
      proxyId: insertInstance.proxyId ?? null,
      status: insertInstance.status ?? "inactive",
      lastRefresh: new Date(),
    };
    this.screenInstances.set(id, instance);
    return instance;
  }

  async updateScreenInstance(id: string, updates: Partial<ScreenInstance>): Promise<ScreenInstance | undefined> {
    const instance = this.screenInstances.get(id);
    if (!instance) return undefined;
    
    const updatedInstance = { ...instance, ...updates };
    this.screenInstances.set(id, updatedInstance);
    return updatedInstance;
  }

  async deleteScreenInstancesBySession(sessionId: string): Promise<boolean> {
    const instances = Array.from(this.screenInstances.entries()).filter(
      ([_, instance]) => instance.sessionId === sessionId
    );
    
    instances.forEach(([id]) => this.screenInstances.delete(id));
    return true;
  }

  async getSystemLogs(limit: number = 50): Promise<SystemLog[]> {
    return Array.from(this.systemLogs.values())
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }

  async createSystemLog(insertLog: InsertSystemLog): Promise<SystemLog> {
    const id = randomUUID();
    const log: SystemLog = {
      id,
      ...insertLog,
      timestamp: new Date(),
    };
    this.systemLogs.set(id, log);
    return log;
  }

  async clearSystemLogs(): Promise<boolean> {
    this.systemLogs.clear();
    return true;
  }
}

export const storage = new MemStorage();
