import { apiRequest } from "./queryClient";

export interface ProxyServer {
  id: string;
  host: string;
  port: number;
  country: string;
  isActive: boolean;
  responseTime?: number;
  lastChecked?: Date;
}

export interface ProxySession {
  id: string;
  targetUrl: string;
  location: string;
  refreshInterval: number;
  isActive: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface ScreenInstance {
  id: string;
  sessionId: string;
  screenNumber: number;
  proxyId: string;
  status: string;
  lastRefresh?: Date;
}

export interface SystemLog {
  id: string;
  level: string;
  message: string;
  timestamp?: Date;
}

export interface SessionData {
  session: ProxySession;
  screens: ScreenInstance[];
}

export const api = {
  // Proxy management
  getProxies: async (): Promise<ProxyServer[]> => {
    const res = await apiRequest("GET", "/api/proxies");
    return res.json();
  },

  getProxiesByCountry: async (country: string): Promise<ProxyServer[]> => {
    const res = await apiRequest("GET", `/api/proxies/${country}`);
    return res.json();
  },

  // Session management
  getActiveSession: async (): Promise<SessionData | null> => {
    try {
      const res = await apiRequest("GET", "/api/session");
      return res.json();
    } catch (error) {
      // Return null if no active session (404)
      return null;
    }
  },

  startSession: async (sessionData: {
    targetUrl: string;
    location: string;
    refreshInterval: number;
  }): Promise<SessionData> => {
    const res = await apiRequest("POST", "/api/session/start", sessionData);
    return res.json();
  },

  stopSession: async (): Promise<{ message: string }> => {
    const res = await apiRequest("POST", "/api/session/stop");
    return res.json();
  },

  refreshAllScreens: async (): Promise<{ message: string; count: number }> => {
    const res = await apiRequest("POST", "/api/session/refresh");
    return res.json();
  },

  // System logs
  getSystemLogs: async (limit?: number): Promise<SystemLog[]> => {
    const url = limit ? `/api/logs?limit=${limit}` : "/api/logs";
    const res = await apiRequest("GET", url);
    return res.json();
  },

  clearSystemLogs: async (): Promise<{ message: string }> => {
    const res = await apiRequest("DELETE", "/api/logs");
    return res.json();
  },

  // Downloads
  downloadApp: async (platform: string): Promise<any> => {
    const res = await apiRequest("GET", `/api/downloads/${platform}`);
    return res.json();
  },
};
