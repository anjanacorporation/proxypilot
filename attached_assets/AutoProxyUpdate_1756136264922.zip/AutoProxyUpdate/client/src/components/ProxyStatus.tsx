import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";
import { api } from "@/lib/api";

interface CountryProxyStatsProps {
  country: string;
  flag: string;
  bgColor: string;
  badgeColor: string;
}

function CountryProxyStats({ country, flag, bgColor, badgeColor }: CountryProxyStatsProps) {
  const { data: proxies = [] } = useQuery({
    queryKey: ["/api/proxies", country],
    queryFn: () => api.getProxiesByCountry(country),
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const activeProxies = proxies.filter(p => p.isActive).length;
  const avgResponseTime = proxies.length > 0 
    ? Math.round(proxies.reduce((sum, p) => sum + (p.responseTime || 0), 0) / proxies.length)
    : 0;

  const countryDisplayName = {
    usa: "USA",
    canada: "Canada", 
    australia: "Australia"
  }[country] || country;

  return (
    <div className={`${bgColor} rounded-lg p-4`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-medium text-gray-900">
          {flag} {countryDisplayName} Proxies
        </h3>
        <span className={`${badgeColor} text-xs px-2 py-1 rounded-full`} data-testid={`proxy-count-${country}`}>
          {proxies.length} Available
        </span>
      </div>
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Active:</span>
          <span className="font-medium text-green-600" data-testid={`active-proxies-${country}`}>
            {activeProxies}/{proxies.length}
          </span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Response Time:</span>
          <span className="font-medium" data-testid={`response-time-${country}`}>
            {avgResponseTime}ms
          </span>
        </div>
      </div>
    </div>
  );
}

export function ProxyStatus() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Proxy Status Monitor</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <CountryProxyStats
            country="usa"
            flag="🇺🇸"
            bgColor="bg-blue-50"
            badgeColor="bg-blue-100 text-blue-800"
          />
          <CountryProxyStats
            country="canada"
            flag="🇨🇦"
            bgColor="bg-red-50"
            badgeColor="bg-red-100 text-red-800"
          />
          <CountryProxyStats
            country="australia"
            flag="🇦🇺"
            bgColor="bg-green-50"
            badgeColor="bg-green-100 text-green-800"
          />
        </div>

        {/* Auto Update Status */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <RefreshCw className="w-4 h-4 text-gray-400 mr-2" />
              <span className="text-sm font-medium text-gray-700">Auto Proxy Update</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">
                Last Update: <span data-testid="last-proxy-update">5 minutes ago</span>
              </span>
              <span className="text-sm text-gray-500">
                Next Update: <span data-testid="next-proxy-update">2 minutes</span>
              </span>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-400 rounded-full mr-1 animate-pulse" />
                <span className="text-sm text-green-600">Active</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
