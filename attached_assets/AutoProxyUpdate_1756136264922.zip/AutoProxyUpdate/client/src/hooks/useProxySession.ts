import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type SessionData } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export function useProxySession() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);

  // Get active session
  const { data: sessionData, isLoading: isLoadingSession } = useQuery({
    queryKey: ["/api/session"],
    queryFn: () => api.getActiveSession(),
    refetchInterval: 5000, // Refetch every 5 seconds to keep status updated
  });

  // Start session mutation
  const startSessionMutation = useMutation({
    mutationFn: api.startSession,
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/session"], data);
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      toast({
        title: "Session Started",
        description: `Started ${data.screens.length} proxy screens successfully`,
      });
      
      // Set up auto-refresh if interval is specified
      if (data.session.refreshInterval > 0) {
        setupAutoRefresh(data.session.refreshInterval);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Start Session",
        description: error.message || "An error occurred while starting the session",
        variant: "destructive",
      });
    },
  });

  // Stop session mutation
  const stopSessionMutation = useMutation({
    mutationFn: api.stopSession,
    onSuccess: () => {
      queryClient.setQueryData(["/api/session"], null);
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      clearAutoRefresh();
      toast({
        title: "Session Stopped",
        description: "All proxy screens have been stopped",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Stop Session",
        description: error.message || "An error occurred while stopping the session",
        variant: "destructive",
      });
    },
  });

  // Refresh all screens mutation
  const refreshAllMutation = useMutation({
    mutationFn: api.refreshAllScreens,
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/session"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      toast({
        title: "Screens Refreshed",
        description: `Refreshed ${data.count} screens successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Refresh Screens",
        description: error.message || "An error occurred while refreshing screens",
        variant: "destructive",
      });
    },
  });

  // Auto-refresh functionality
  const setupAutoRefresh = (intervalSeconds: number) => {
    clearAutoRefresh();
    const interval = setInterval(() => {
      if (sessionData?.session?.isActive) {
        refreshAllMutation.mutate();
      }
    }, intervalSeconds * 1000);
    setRefreshInterval(interval);
  };

  const clearAutoRefresh = () => {
    if (refreshInterval) {
      clearInterval(refreshInterval);
      setRefreshInterval(null);
    }
  };

  // Clean up interval on unmount or when session becomes inactive
  useEffect(() => {
    if (!sessionData?.session?.isActive) {
      clearAutoRefresh();
    }
    
    return () => {
      clearAutoRefresh();
    };
  }, [sessionData?.session?.isActive]);

  return {
    sessionData,
    isLoadingSession,
    isSessionActive: !!sessionData?.session?.isActive,
    startSession: startSessionMutation.mutate,
    stopSession: stopSessionMutation.mutate,
    refreshAllScreens: refreshAllMutation.mutate,
    isStarting: startSessionMutation.isPending,
    isStopping: stopSessionMutation.isPending,
    isRefreshing: refreshAllMutation.isPending,
  };
}
