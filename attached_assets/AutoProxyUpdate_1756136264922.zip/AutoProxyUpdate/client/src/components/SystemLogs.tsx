import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export function SystemLogs() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: logs = [] } = useQuery({
    queryKey: ["/api/logs"],
    queryFn: () => api.getSystemLogs(50),
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  const clearLogsMutation = useMutation({
    mutationFn: api.clearSystemLogs,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
      toast({
        title: "Logs Cleared",
        description: "System logs have been cleared successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Clear Logs",
        description: error.message || "An error occurred while clearing logs",
        variant: "destructive",
      });
    },
  });

  const getLogColor = (level: string) => {
    switch (level) {
      case "success":
        return "text-green-400";
      case "info":
        return "text-blue-400";
      case "warning":
        return "text-yellow-400";
      case "error":
        return "text-red-400";
      default:
        return "text-gray-400";
    }
  };

  const formatTimestamp = (timestamp?: Date | string) => {
    if (!timestamp) return "[--:--:--]";
    const date = typeof timestamp === "string" ? new Date(timestamp) : timestamp;
    return `[${date.toLocaleTimeString()}]`;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>System Logs</CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={() => clearLogsMutation.mutate()}
            disabled={clearLogsMutation.isPending}
            data-testid="button-clear-logs"
          >
            <Trash2 className="w-4 h-4 mr-1" />
            {clearLogsMutation.isPending ? "Clearing..." : "Clear Logs"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div 
          className="bg-gray-900 rounded-lg p-4 h-64 overflow-y-auto font-mono text-sm"
          data-testid="system-logs-container"
        >
          <div className="space-y-2">
            {logs.length === 0 ? (
              <div className="text-gray-400">No logs available</div>
            ) : (
              logs.map((log) => (
                <div 
                  key={log.id} 
                  className={getLogColor(log.level)}
                  data-testid={`log-entry-${log.level}`}
                >
                  {formatTimestamp(log.timestamp)} {log.message}
                </div>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
