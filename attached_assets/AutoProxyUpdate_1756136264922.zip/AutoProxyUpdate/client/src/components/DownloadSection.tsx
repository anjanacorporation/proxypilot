import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Clock } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface DownloadCardProps {
  platform: string;
  icon: string;
  title: string;
  description: string;
  buttonText: string;
  buttonColor: string;
  version: string;
  size: string;
  status: "available" | "coming_soon";
}

function DownloadCard({ 
  platform, 
  icon, 
  title, 
  description, 
  buttonText, 
  buttonColor, 
  version, 
  size, 
  status 
}: DownloadCardProps) {
  const [isDownloading, setIsDownloading] = useState(false);
  const { toast } = useToast();

  const handleDownload = async () => {
    if (status === "coming_soon") return;
    
    setIsDownloading(true);
    try {
      const result = await api.downloadApp(platform);
      toast({
        title: "Download Initiated",
        description: `Downloading ${result.filename} (${result.size})`,
      });
    } catch (error: any) {
      toast({
        title: "Download Failed",
        description: error.message || "Failed to initiate download",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="border border-gray-200 rounded-lg p-6 text-center hover:shadow-md transition-shadow duration-200">
      <div className="mb-4">
        <div className="text-4xl">{icon}</div>
      </div>
      <h3 className="font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-sm text-gray-600 mb-4">{description}</p>
      <Button
        onClick={handleDownload}
        disabled={status === "coming_soon" || isDownloading}
        className={`w-full ${buttonColor} font-medium transition-colors duration-200`}
        data-testid={`button-download-${platform}`}
      >
        {status === "coming_soon" ? (
          <>
            <Clock className="w-4 h-4 mr-2" />
            Coming Soon
          </>
        ) : (
          <>
            <Download className="w-4 h-4 mr-2" />
            {isDownloading ? "Downloading..." : buttonText}
          </>
        )}
      </Button>
      <p className="text-xs text-gray-500 mt-2" data-testid={`download-info-${platform}`}>
        {status === "coming_soon" ? "In Development" : `${version} • ${size}`}
      </p>
    </div>
  );
}

export function DownloadSection() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Desktop Applications</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <DownloadCard
            platform="windows"
            icon="🖥️"
            title="Windows"
            description="Compatible with Windows 10 and 11"
            buttonText="Download .exe"
            buttonColor="bg-blue-600 hover:bg-blue-700 text-white"
            version="Version 1.0.0"
            size="45.2 MB"
            status="available"
          />
          
          <DownloadCard
            platform="macos"
            icon="🍎"
            title="macOS"
            description="Compatible with macOS 10.15+"
            buttonText="Download .dmg"
            buttonColor="bg-gray-800 hover:bg-gray-900 text-white"
            version="Version 1.0.0"
            size="52.1 MB"
            status="available"
          />
          
          <DownloadCard
            platform="linux"
            icon="🐧"
            title="Linux"
            description="AppImage format for all distributions"
            buttonText="Download .AppImage"
            buttonColor="bg-orange-600 hover:bg-orange-700 text-white"
            version="Version 1.0.0"
            size="48.7 MB"
            status="available"
          />
        </div>

        {/* Mobile App Section */}
        <div className="mt-8 pt-6 border-t border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Mobile Applications</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <DownloadCard
              platform="android"
              icon="🤖"
              title="Android"
              description="WebView wrapper for mobile access"
              buttonText="Download APK"
              buttonColor="bg-green-600 hover:bg-green-700 text-white"
              version="Version 1.0.0"
              size="25.3 MB"
              status="coming_soon"
            />
            
            <DownloadCard
              platform="ios"
              icon="📱"
              title="iOS"
              description="WebView wrapper for iPhone/iPad"
              buttonText="Coming Soon"
              buttonColor="bg-gray-400 text-white cursor-not-allowed"
              version="Version 1.0.0"
              size="30.1 MB"
              status="coming_soon"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
