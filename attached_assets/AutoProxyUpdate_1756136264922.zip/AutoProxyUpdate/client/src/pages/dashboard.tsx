import { Header } from "@/components/Header";
import { ControlPanel } from "@/components/ControlPanel";
import { ScreenGrid } from "@/components/ScreenGrid";
import { ProxyStatus } from "@/components/ProxyStatus";
import { SystemLogs } from "@/components/SystemLogs";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <ControlPanel />
        </div>
      </main>
      
      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <span className="font-semibold text-gray-900">Multi-Proxy Screen Manager</span>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Advanced proxy management system for multi-screen browsing with automatic proxy rotation and real-time monitoring.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Features</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>10-Screen Grid Layout</li>
                <li>Automatic Proxy Rotation</li>
                <li>Real-time Monitoring</li>
                <li>Cross-platform Apps</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Support</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-primary">Documentation</a></li>
                <li><a href="#" className="hover:text-primary">API Reference</a></li>
                <li><a href="#" className="hover:text-primary">Contact Support</a></li>
                <li><a href="#" className="hover:text-primary">Report Bug</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-200 mt-8 pt-8 text-center text-sm text-gray-500">
            <p>&copy; 2024 Multi-Proxy Screen Manager. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
