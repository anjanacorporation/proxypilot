#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('📱 Building Multi-Proxy Screen Manager Mobile Apps...\n');

// Check if mobile-app directory exists
if (!fs.existsSync('mobile-app')) {
  console.error('❌ Mobile app directory not found!');
  process.exit(1);
}

// Function to run command and handle errors
function runCommand(command, description) {
  console.log(`📦 ${description}...`);
  try {
    execSync(command, { stdio: 'inherit', cwd: 'mobile-app' });
    console.log(`✅ ${description} completed!\n`);
  } catch (error) {
    console.error(`❌ ${description} failed:`, error.message);
    return false;
  }
  return true;
}

// Build steps
try {
  // Install mobile app dependencies
  console.log('📥 Installing mobile app dependencies...');
  if (!runCommand('npm install', 'Mobile dependencies installation')) {
    console.log('⚠️  Trying with Expo CLI...');
    runCommand('npx expo install', 'Expo dependencies installation');
  }

  console.log('🏗️  Setting up Expo development build...');
  
  // Check if EAS CLI is installed
  try {
    execSync('eas --version', { stdio: 'ignore' });
  } catch {
    console.log('📥 Installing EAS CLI...');
    runCommand('npm install -g @expo/eas-cli', 'EAS CLI installation');
  }

  // Login instructions
  console.log('\n📋 Mobile App Build Instructions:');
  console.log('');
  console.log('To build the mobile app, follow these steps:');
  console.log('');
  console.log('1. 📧 Create an Expo account at https://expo.dev');
  console.log('2. 🔐 Login to EAS CLI:');
  console.log('   cd mobile-app && eas login');
  console.log('');
  console.log('3. 🛠️  Configure the project:');
  console.log('   eas build:configure');
  console.log('');
  console.log('4. 🤖 Build for Android:');
  console.log('   eas build --platform android');
  console.log('');
  console.log('5. 🍎 Build for iOS (requires Apple Developer account):');
  console.log('   eas build --platform ios');
  console.log('');
  console.log('6. 📱 Install on device:');
  console.log('   - Android: Download APK from Expo dashboard');
  console.log('   - iOS: Install via TestFlight or App Store Connect');
  console.log('');
  
  console.log('💡 Alternative: Development build');
  console.log('   npx expo start');
  console.log('   - Scan QR code with Expo Go app');
  console.log('');

  // Create a simple setup script
  const setupScript = `#!/bin/bash
echo "🚀 Setting up Mobile App Build Environment..."

# Install dependencies
npm install

# Check if EAS CLI is installed globally
if ! command -v eas &> /dev/null; then
    echo "📥 Installing EAS CLI..."
    npm install -g @expo/eas-cli
fi

echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Run: eas login"
echo "2. Run: eas build:configure"
echo "3. Run: eas build --platform android"
echo ""
`;

  fs.writeFileSync(path.join('mobile-app', 'setup.sh'), setupScript);
  fs.chmodSync(path.join('mobile-app', 'setup.sh'), '755');

  console.log('✅ Mobile app setup completed!');
  console.log('📁 Setup script created: mobile-app/setup.sh');

} catch (error) {
  console.error('❌ Mobile build setup failed:', error.message);
  process.exit(1);
}