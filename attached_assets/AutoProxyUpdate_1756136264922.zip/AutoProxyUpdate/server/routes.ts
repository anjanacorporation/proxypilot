import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProxySessionSchema, insertSystemLogSchema } from "@shared/schema";
import { createProxyMiddleware } from 'http-proxy-middleware';

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get proxy servers by country
  app.get("/api/proxies/:country", async (req, res) => {
    try {
      const { country } = req.params;
      const proxies = await storage.getProxyServersByCountry(country);
      res.json(proxies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch proxies" });
    }
  });

  // Get all proxy servers
  app.get("/api/proxies", async (req, res) => {
    try {
      const proxies = await storage.getProxyServers();
      res.json(proxies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch proxies" });
    }
  });

  // Get active session
  app.get("/api/session", async (req, res) => {
    try {
      const session = await storage.getActiveSession();
      if (!session) {
        return res.status(404).json({ error: "No active session found" });
      }
      
      const screens = await storage.getScreenInstancesBySession(session.id);
      res.json({ session, screens });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch session" });
    }
  });

  // Start new proxy session
  app.post("/api/session/start", async (req, res) => {
    try {
      const validatedData = insertProxySessionSchema.parse(req.body);
      
      // Stop any existing active session
      const existingSession = await storage.getActiveSession();
      if (existingSession) {
        await storage.updateProxySession(existingSession.id, { isActive: false });
        await storage.deleteScreenInstancesBySession(existingSession.id);
      }

      // Create new session
      const session = await storage.createProxySession({
        ...validatedData,
        isActive: true,
      });

      // Get proxies for the selected location
      const proxies = await storage.getProxyServersByCountry(validatedData.location);
      
      if (proxies.length === 0) {
        await storage.createSystemLog({
          level: "error",
          message: `No proxies available for ${validatedData.location}`
        });
        return res.status(400).json({ error: `No proxies available for ${validatedData.location}` });
      }

      // Create 10 screen instances with rotating proxies
      const screens = [];
      for (let i = 1; i <= 10; i++) {
        const proxy = proxies[(i - 1) % proxies.length];
        const screen = await storage.createScreenInstance({
          sessionId: session.id,
          screenNumber: i,
          proxyId: proxy.id,
          status: "active",
        });
        screens.push(screen);
      }

      await storage.createSystemLog({
        level: "success",
        message: `Started new session with ${screens.length} screens for ${validatedData.location}`
      });

      res.json({ session, screens });
    } catch (error) {
      console.error('Error starting session:', error);
      await storage.createSystemLog({
        level: "error",
        message: `Failed to start session: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
      res.status(500).json({ error: "Failed to start session" });
    }
  });

  // Stop active session
  app.post("/api/session/stop", async (req, res) => {
    try {
      const session = await storage.getActiveSession();
      if (!session) {
        return res.status(404).json({ error: "No active session found" });
      }

      await storage.updateProxySession(session.id, { isActive: false });
      await storage.deleteScreenInstancesBySession(session.id);

      await storage.createSystemLog({
        level: "info",
        message: "Session stopped successfully"
      });

      res.json({ message: "Session stopped successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to stop session" });
    }
  });

  // Refresh all screens
  app.post("/api/session/refresh", async (req, res) => {
    try {
      const session = await storage.getActiveSession();
      if (!session) {
        return res.status(404).json({ error: "No active session found" });
      }

      const screens = await storage.getScreenInstancesBySession(session.id);
      
      // Update all screen refresh timestamps
      for (const screen of screens) {
        await storage.updateScreenInstance(screen.id, { 
          lastRefresh: new Date() 
        });
      }

      await storage.createSystemLog({
        level: "info",
        message: `Refreshed ${screens.length} screens`
      });

      res.json({ message: "All screens refreshed", count: screens.length });
    } catch (error) {
      res.status(500).json({ error: "Failed to refresh screens" });
    }
  });

  // Get system logs
  app.get("/api/logs", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const logs = await storage.getSystemLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch logs" });
    }
  });

  // Clear system logs
  app.delete("/api/logs", async (req, res) => {
    try {
      await storage.clearSystemLogs();
      await storage.createSystemLog({
        level: "info",
        message: "System logs cleared"
      });
      res.json({ message: "Logs cleared successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear logs" });
    }
  });

  // Proxy endpoint for screen content
  app.use("/api/proxy/:screenId", (req, res, next) => {
    const { screenId } = req.params;
    const targetUrl = req.query.url as string;
    
    if (!targetUrl) {
      return res.status(400).json({ error: "URL parameter required" });
    }

    // Create proxy middleware for this request
    const proxy = createProxyMiddleware({
      target: targetUrl,
      changeOrigin: true,
      pathRewrite: {
        [`^/api/proxy/${screenId}`]: '',
      },
      onProxyReq: (proxyReq: any, req: any, res: any) => {
        // Add headers to avoid CORS issues
        proxyReq.setHeader('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
      },
      onProxyRes: (proxyRes: any, req: any, res: any) => {
        // Add CORS headers
        proxyRes.headers['Access-Control-Allow-Origin'] = '*';
        proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
        proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
      }
    });

    proxy(req, res, next);
  });

  // Download endpoints (placeholder for now)
  app.get("/api/downloads/:platform", (req, res) => {
    const { platform } = req.params;
    const downloads = {
      windows: { filename: "ProxyManager-1.0.0.exe", size: "45.2 MB" },
      macos: { filename: "ProxyManager-1.0.0.dmg", size: "52.1 MB" },
      linux: { filename: "ProxyManager-1.0.0.AppImage", size: "48.7 MB" },
      android: { filename: "ProxyManager-1.0.0.apk", size: "25.3 MB" }
    };

    const download = downloads[platform as keyof typeof downloads];
    if (!download) {
      return res.status(404).json({ error: "Platform not found" });
    }

    res.json({ 
      message: `Download for ${platform} requested`,
      filename: download.filename,
      size: download.size,
      status: platform === 'android' || platform === 'ios' ? 'coming_soon' : 'available'
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
