import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link2, Clock, Play, Square, RefreshCw, ArrowLeft, MapPin, Globe, Wifi } from "lucide-react";
import { useProxySession } from "@/hooks/useProxySession";
import { Link, useLocation } from "wouter";
import { ScreenGrid } from "@/components/ScreenGrid";
import { ProxyStatus } from "@/components/ProxyStatus";
import { SystemLogs } from "@/components/SystemLogs";
import { useQuery } from "@tanstack/react-query";

export default function ProxySession() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const selectedLocation = searchParams.get('location') || '';
  
  const [targetUrl, setTargetUrl] = useState("");
  const [refreshInterval, setRefreshInterval] = useState("30");

  // Fetch proxies for the selected location
  const { data: proxies } = useQuery({
    queryKey: ['/api/proxies', selectedLocation],
    enabled: !!selectedLocation,
  });
  
  const {
    sessionData,
    isSessionActive,
    startSession,
    stopSession,
    refreshAllScreens,
    isStarting,
    isStopping,
    isRefreshing,
  } = useProxySession();

  const handleStart = () => {
    if (!selectedLocation || !targetUrl) {
      return;
    }
    
    startSession({
      targetUrl,
      location: selectedLocation,
      refreshInterval: parseInt(refreshInterval),
    });
  };

  const activeScreensCount = sessionData?.screens?.filter(screen => screen.status === "active").length || 0;

  // Get proxy details for display
  const getLocationDisplay = (loc: string) => {
    switch(loc) {
      case 'usa': return { flag: '🇺🇸', name: 'United States', region: 'North America' };
      case 'canada': return { flag: '🇨🇦', name: 'Canada', region: 'North America' };
      case 'australia': return { flag: '🇦🇺', name: 'Australia', region: 'Oceania' };
      default: return { flag: '🌍', name: 'Unknown', region: 'Unknown' };
    }
  };

  const locationInfo = getLocationDisplay(selectedLocation);

  // Get actual proxy details from API data
  const firstProxy = Array.isArray(proxies) && proxies.length > 0 ? proxies[0] : null;
  const proxyDetails = firstProxy ? {
    ip: firstProxy.host,
    port: firstProxy.port.toString(),
    responseTime: firstProxy.responseTime + 'ms',
    status: firstProxy.isActive ? 'Connected' : 'Disconnected',
    city: firstProxy.city || 'Unknown City',
    country: firstProxy.country || selectedLocation.toUpperCase()
  } : {
    ip: '0.0.0.0',
    port: '0',
    responseTime: '0ms',
    status: 'Disconnected',
    city: 'Unknown City',
    country: selectedLocation.toUpperCase()
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Location Selection
            </Button>
          </Link>
          <div className="flex items-center gap-4 mb-2">
            <h1 className="text-3xl font-bold text-gray-900">Proxy Session</h1>
            <Badge variant="outline" className="text-lg px-3 py-1">
              {locationInfo.flag} {locationInfo.name}
            </Badge>
          </div>
          <p className="text-gray-600">Configure your session and manage proxy screens</p>
        </div>

        <div className="space-y-8">
          {/* Proxy Connection Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Wifi className="w-5 h-5 mr-2" />
                Connected Proxy Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="text-sm text-gray-500">Location</p>
                    <p className="font-medium">{locationInfo.flag} {locationInfo.name}</p>
                    <p className="text-xs text-gray-400">{proxyDetails.city}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Globe className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-sm text-gray-500">IP Address</p>
                    <p className="font-medium">{proxyDetails.ip}:{proxyDetails.port}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Wifi className="w-5 h-5 text-purple-500" />
                  <div>
                    <p className="text-sm text-gray-500">Response Time</p>
                    <p className="font-medium">{proxyDetails.responseTime}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${proxyDetails.status === 'Connected' ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    <p className={`font-medium ${proxyDetails.status === 'Connected' ? 'text-green-600' : 'text-red-600'}`}>
                      {proxyDetails.status}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Session Configuration */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {/* Target URL Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle>Target URL</CardTitle>
                </CardHeader>
                <CardContent>
                  <div>
                    <Label htmlFor="target-url" className="flex items-center text-sm font-medium text-gray-700 mb-2">
                      <Link2 className="w-4 h-4 text-gray-400 mr-2" />
                      Website URL
                    </Label>
                    <Input
                      id="target-url"
                      type="url"
                      placeholder="https://example.com"
                      value={targetUrl}
                      onChange={(e) => setTargetUrl(e.target.value)}
                      disabled={isSessionActive}
                      data-testid="input-target-url"
                      className="text-lg"
                    />
                    <p className="text-sm text-gray-500 mt-2">
                      Enter the website URL you want to view through proxy screens
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Refresh Interval Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle>Auto Refresh Settings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="max-w-md">
                    <Label htmlFor="refresh-interval" className="flex items-center text-sm font-medium text-gray-700 mb-2">
                      <Clock className="w-4 h-4 text-gray-400 mr-2" />
                      Refresh Interval
                    </Label>
                    <Select 
                      value={refreshInterval} 
                      onValueChange={setRefreshInterval}
                      disabled={isSessionActive}
                    >
                      <SelectTrigger data-testid="select-refresh-interval">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 seconds</SelectItem>
                        <SelectItem value="30">30 seconds</SelectItem>
                        <SelectItem value="60">60 seconds</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-gray-500 mt-2">
                      How often should all screens automatically refresh
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Session Control */}
            <Card>
              <CardHeader>
                <CardTitle>Session Control</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button
                    onClick={handleStart}
                    disabled={isSessionActive || isStarting || !targetUrl}
                    className="w-full bg-primary hover:bg-primary/90"
                    data-testid="button-start-session"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {isStarting ? "Starting..." : "Start Proxy Session"}
                  </Button>
                  
                  <Button
                    onClick={() => stopSession()}
                    disabled={!isSessionActive || isStopping}
                    variant="destructive"
                    className="w-full"
                    data-testid="button-stop-session"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    {isStopping ? "Stopping..." : "Stop Session"}
                  </Button>
                  
                  <Button
                    onClick={() => refreshAllScreens()}
                    disabled={!isSessionActive || isRefreshing}
                    variant="secondary"
                    className="w-full"
                    data-testid="button-refresh-all"
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
                    {isRefreshing ? "Refreshing..." : "Refresh All"}
                  </Button>

                  <div className="pt-4 space-y-3 border-t">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Status:</span>
                      <div className="flex items-center">
                        <div className={`w-2 h-2 rounded-full mr-2 ${
                          isSessionActive ? "bg-green-400 animate-pulse" : "bg-gray-400"
                        }`} />
                        <span className="text-sm font-medium" data-testid="status-text">
                          {isSessionActive ? "Active" : "Inactive"}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Active Screens:</span>
                      <span className="text-sm font-medium" data-testid="active-proxies-count">
                        {activeScreensCount}/10
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Current Session Info */}
          {sessionData?.session && (
            <Card>
              <CardHeader>
                <CardTitle>Current Session Info</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-700">Target URL:</span>
                    <p className="text-gray-600 break-all">{sessionData.session.targetUrl}</p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Location:</span>
                    <p className="text-gray-600 capitalize">{sessionData.session.location}</p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Refresh Interval:</span>
                    <p className="text-gray-600">{sessionData.session.refreshInterval} seconds</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Proxy Screens Grid */}
          <ScreenGrid />

          {/* Monitoring Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <ProxyStatus />
            <SystemLogs />
          </div>
        </div>
      </main>
    </div>
  );
}