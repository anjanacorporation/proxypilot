# Overview

This is a full-stack multi-proxy screen management system that allows users to view websites through multiple proxy servers in a 10-screen grid layout. The application provides proxy rotation capabilities, real-time monitoring, and cross-platform desktop applications. Users can select different geographic locations (USA, Canada, Australia), input target URLs, set refresh intervals, and monitor proxy performance through an intuitive dashboard interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React 18** with TypeScript for type safety and modern React features
- **Vite** as the build tool for fast development and optimized production builds
- **Wouter** for lightweight client-side routing instead of React Router
- **TanStack Query** for server state management, caching, and synchronization
- **Shadcn/ui** component library built on Radix UI primitives for accessible, customizable components
- **Tailwind CSS** for utility-first styling with custom design tokens and CSS variables
- **Component Structure**: Modular components including ControlPanel, ScreenGrid, ProxyStatus, SystemLogs, and DownloadSection

## Backend Architecture
- **Node.js** with Express.js framework for the REST API server
- **TypeScript** throughout the entire stack for consistent type safety
- **In-memory storage** implementation with interfaces designed for easy database integration
- **http-proxy-middleware** for handling proxy requests and routing traffic through different proxy servers
- **RESTful API** design with endpoints for proxy management, session control, and system monitoring
- **Middleware pattern** for request logging, error handling, and response transformation

## Data Layer
- **Drizzle ORM** configured for PostgreSQL with schema definitions
- **Zod schemas** for runtime type validation and API request/response validation
- **Database schema** includes proxy servers, sessions, screen instances, and system logs tables
- **In-memory fallback** storage implementation for development and testing

## Session Management
- **Proxy Sessions**: Central concept managing 10-screen configurations with target URLs, geographic locations, and refresh intervals
- **Screen Instances**: Individual screen state management with proxy assignments and status tracking
- **Auto-refresh mechanism**: Configurable intervals for automatic screen updates
- **Real-time monitoring**: WebSocket-like polling for status updates and system logs

## Proxy Management
- **Geographic proxy selection**: Support for USA, Canada, and Australia proxy servers
- **Health monitoring**: Response time tracking and availability checks for proxy servers
- **Load balancing**: Random proxy assignment across the 10-screen grid
- **Failover handling**: Automatic proxy switching when servers become unavailable

## Development Tooling
- **Vite configuration** with React plugin and development error overlays
- **ESBuild** for production server bundling
- **Path mapping** for clean imports using @ aliases
- **Development middleware** for hot module replacement and asset serving

# External Dependencies

## Core Framework Dependencies
- **@vitejs/plugin-react**: React integration for Vite build system
- **express**: Node.js web framework for API server
- **drizzle-orm**: Type-safe SQL ORM for database operations
- **@neondatabase/serverless**: PostgreSQL database connection for serverless environments

## UI and Styling
- **@radix-ui/***: Comprehensive set of accessible, unstyled UI primitives
- **tailwindcss**: Utility-first CSS framework for rapid styling
- **class-variance-authority**: Utility for managing component variants
- **lucide-react**: Icon library with consistent, customizable icons

## State Management and Data Fetching
- **@tanstack/react-query**: Server state management with caching and synchronization
- **wouter**: Minimalist client-side routing library
- **zod**: Schema validation library for runtime type checking

## Development and Build Tools
- **typescript**: Type safety across frontend and backend
- **tsx**: TypeScript execution environment for development
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-runtime-error-modal**: Development error handling overlay

## Proxy and Networking
- **http-proxy-middleware**: Middleware for proxying HTTP requests through different servers
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## Utility Libraries
- **date-fns**: Date manipulation and formatting utilities
- **clsx**: Conditional CSS class name utility
- **cmdk**: Command palette component for enhanced UX